package com.capgemini.web.ars.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import javax.servlet.http.HttpSession;

import org.jboss.security.ISecurityManagement;

import com.capgemini.web.ars.bean.Airport;
import com.capgemini.web.ars.bean.FlightInformation;
import com.capgemini.web.ars.service.AirlineReservationServiceImpl;
import com.capgemini.web.ars.service.IAirlineReservationService;
import com.capgemini.web.ars.util.DbUtil;


@WebServlet("*.do")
public class Controller extends HttpServlet {

	Connection conn = null;
	PreparedStatement pstm = null; 
	
	//getting airports data for reusability
	HashMap<String, Airport> airportData =  new HashMap<>(); 
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String action = request.getServletPath();
		
		IAirlineReservationService servObj = new AirlineReservationServiceImpl();
		
		 airportData= servObj.getAirportList();
		switch(action){
		
		case "/login.do":
			
			RequestDispatcher view= request.getRequestDispatcher("login.jsp");
			view.forward(request, response);
			
		break;
		
		case "/enter.do":
			String uname=request.getParameter("uname");
			String pass=request.getParameter("pass");
	
			try
			{
					conn = DbUtil.getConnection();
					PreparedStatement pstm=conn.prepareStatement("Select role from  users"
							+ " where username = ? and password = ? ");
					pstm.setString(1,uname);
					pstm.setString(2, pass);
					ResultSet res = pstm.executeQuery();
					
					 String roles=null;
					 
					 if(res.next())
					 {
						  roles=res.getString("role");
					 } 
					
					  if(roles==null || roles.equals(""))
					    {
					    	  
							  response.sendRedirect("login.jsp");	
					    }
				 
					  else if(roles.equals("admin")) 
						    { 				       
						      //converting keyset to arraylist
						       Set<String> arpAbbSet = airportData.keySet();
						       ArrayList<String> airportList = new ArrayList(arpAbbSet);
						  
						   		
						   		request.setAttribute("role", roles);
						   		HttpSession session = request.getSession();
						   		session.setAttribute("arpList",airportList);
						    
						   		System.out.println(airportList);
						   		RequestDispatcher rd = request.getRequestDispatcher("Admin.jsp");
						   		rd.forward(request, response);
						    } 
					  else if(roles.equals("executive")) 
						    { 
						    	System.out.println(roles); 
						    	request.setAttribute("type", roles);
						    	RequestDispatcher rd = request.getRequestDispatcher("Excecutive.jsp");
						    	rd.forward(request, response);
						    } 
					  
			}
			
				 
			 catch (NamingException | SQLException e)
			{
				e.printStackTrace();
			}
			
			
			break;
			
            case "/addFlight.do":
			
            	 String flightno = request.getParameter("flightId");
            	 String airline = request.getParameter("airline");
            	 String depArpAbb = request.getParameter("depArp");
            	 String arrArpAbb = request.getParameter("arrArp");
            	 String dep_date = request.getParameter("depDate");
            	 String arr_date = request.getParameter("arrDate");
            	 String dep_time = request.getParameter("depTime");
            	 String arr_time = request.getParameter("arrTime");
            	 String FirstSeats = request.getParameter("FirstSeats");
            	 String FirstSeatFare = request.getParameter("FirstSeatFare");
            	 String BussSeats = request.getParameter("BussSeats");
            	 String BussSeatsFare= request.getParameter("BussSeatsFare");
            	
            	 
            	 //getting Airport data from abbreviation
            	 Airport depArp = airportData.get(depArpAbb);
            	 Airport arrArp = airportData.get(arrArpAbb);
            	 
            	 
            	 //converting string date to sql date
            	 Date depDatesql = null;
            	 Date arrDatesql = null;
            	 SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            	 
            	 try 
            	 	{
            		 	java.util.Date depDateUtil = format.parse(dep_date);
            		 	depDatesql = new java.sql.Date(depDateUtil.getTime());
                 
            		 	java.util.Date arrDateUtil = format.parse(dep_date);
            		 	arrDatesql = new java.sql.Date(depDateUtil.getTime());
            	 	} 
            	 catch (ParseException e) 
            	 {
            		 e.printStackTrace();
            	 }
                 
            	 FlightInformation fi = new FlightInformation();
            	 
            	 fi.setFlightno(Integer.parseInt(flightno));
            	 fi.setAirline(airline);
            	 fi.setDepArp(depArp);
            	 fi.setArrArp(arrArp);
            	 fi.setDep_date(depDatesql);
            	 fi.setArr_date(arrDatesql);
            	 fi.setDep_time(dep_time);
            	 fi.setArr_time(arr_time);
            	 fi.setFirstSeats(Integer.parseInt(FirstSeats));
            	 fi.setFirstSeatFare(Double.parseDouble(FirstSeatFare));
            	 fi.setBussSeats(Integer.parseInt(BussSeats));
            	 fi.setBussSeatsFare(Double.parseDouble(BussSeatsFare));
                 
            	 servObj.addFlightInformation(fi);
            	 
            	 response.sendRedirect("showAllFlights.do");
	     	break;
	     	

    		case "/showAllFlights.do":
    			
    			ArrayList<FlightInformation> allFlightInfo = servObj.showAllFlights();
    			
    			request.setAttribute("flightData", allFlightInfo);
    			RequestDispatcher rd = request.getRequestDispatcher("showFlights.jsp");
		   		rd.forward(request, response);
    			
    		break;
    		
    		case "/bookFlight.do":
    			
    			    Set<String> arpAbbSet = airportData.keySet();
			        ArrayList<String> airportList = new ArrayList(arpAbbSet);
			 
			   		HttpSession session = request.getSession();
			   		session.setAttribute("arpList",airportList);
    			
    			      RequestDispatcher dis = request.getRequestDispatcher("bookFlight.jsp");
    			      dis.forward(request, response);
    			
    		break;
    		case "/processBookingDetails.do":
    		
    			 depArpAbb = request.getParameter("depArp");
    		     arrArpAbb = request.getParameter("arrArp");
    		     
    		     arr_date = request.getParameter("arrDate");
    		     dep_date = request.getParameter("depDate");
    		     
    		     String trip = request.getParameter("flightWay");
    		     
    		     //converting string date to sql date
            	 depDatesql = null;
            	 arrDatesql = null;
            	 format = new SimpleDateFormat("yyyy-MM-dd");
            	 
            	 try 
            	 	{
            		 	java.util.Date depDateUtil = format.parse(dep_date);
            		 	depDatesql = new java.sql.Date(depDateUtil.getTime());
                 
            		 	java.util.Date arrDateUtil = format.parse(dep_date);
            		 	arrDatesql = new java.sql.Date(depDateUtil.getTime());
            	 	} 
            	 catch (ParseException e) 
            	 	{
            		 	e.printStackTrace();
            	 	}
    		
    		     ArrayList<FlightInformation> upFlights = servObj.viewFlightOn(depArpAbb, arrArpAbb, arrDatesql);
    		     ArrayList<FlightInformation> downFlights = servObj.viewFlightOn(depArpAbb, arrArpAbb, depDatesql);
    		break;
    		
    		case "/update.do":
    			
    			System.out.println(request.getAttribute("flightlist"));
    			
    			 String flightno1 = request.getParameter("flightId");
            	 String airline1 = request.getParameter("airline");
            	 String depArpAbb1 = request.getParameter("depArp");
            	 String arrArpAbb1 = request.getParameter("arrArp");
            	 String dep_date1 = request.getParameter("depDate");
            	 String arr_date1 = request.getParameter("arrDate");
            	 String dep_time1 = request.getParameter("depTime");
            	 String arr_time1 = request.getParameter("arrTime");
            	 String FirstSeats1 = request.getParameter("FirstSeats");
            	 String FirstSeatFare1 = request.getParameter("FirstSeatFare");
            	 String BussSeats1 = request.getParameter("BussSeats");
            	 String BussSeatsFare1= request.getParameter("BussSeatsFare");
            	
            	 
            	 //getting Airport data from abbreviation
            	 Airport depArp1 = airportData.get(depArpAbb1);
            	 Airport arrArp1 = airportData.get(arrArpAbb1);
            	 
            	 //converting string date to sql date
           	 Date depDatesql1 = null;
           	 Date arrDatesql1 = null;
            	 
           	 System.out.println(dep_date1);
           	 System.out.println(arr_date1);
            	 
            	 SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
            	 
            	 
            	 try 
            	 	{
            		 	java.util.Date depDateUtil = format1.parse(dep_date1);
            		 	depDatesql = new java.sql.Date(depDateUtil.getTime());
                 
            		 	java.util.Date arrDateUtil = format1.parse(dep_date1);
            		 	arrDatesql = new java.sql.Date(depDateUtil.getTime());
            	 	} 
            	 catch (ParseException e) 
            	 {
            		 e.printStackTrace();
            	 }
                 
            	 FlightInformation fi1 = new FlightInformation();
            	 
            	 fi1.setFlightno(Integer.parseInt(flightno1));
            	 fi1.setAirline(airline1);
            	 fi1.setDepArp(depArp1);
            	 fi1.setArrArp(arrArp1);
            	 fi1.setDep_date(depDatesql1);
            	 fi1.setArr_date(arrDatesql1);
            	 fi1.setDep_time(dep_time1);
            	 fi1.setArr_time(arr_time1);
            	 fi1.setFirstSeats(Integer.parseInt(FirstSeats1));
            	 fi1.setFirstSeatFare(Double.parseDouble(FirstSeatFare1));
            	 fi1.setBussSeats(Integer.parseInt(BussSeats1));
            	 fi1.setBussSeatsFare(Double.parseDouble(BussSeatsFare1));
                 
            	 servObj.updateFlightInformation(fi1);;
            	 RequestDispatcher view1 = request.getRequestDispatcher("edit.jsp");
     			view1.forward(request, response);
     			
    		case "/remove.do":
    			
    			System.out.println();
    			
    			break;
		}
	}
	
}
