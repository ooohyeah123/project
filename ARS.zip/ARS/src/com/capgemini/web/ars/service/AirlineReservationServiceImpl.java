package com.capgemini.web.ars.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;

import com.capgemini.web.ars.bean.Airport;
import com.capgemini.web.ars.bean.BookingInformation;
import com.capgemini.web.ars.bean.FlightInformation;
import com.capgemini.web.ars.dao.AirlineReservationDaoImpl;
import com.capgemini.web.ars.dao.IAirlineReservationDao;

public class AirlineReservationServiceImpl implements IAirlineReservationService
{
	IAirlineReservationDao daoObj;
	
	public AirlineReservationServiceImpl() 
	{
		daoObj = new AirlineReservationDaoImpl();
	}

	@Override
	public void addAirport(Airport ap) 
	{
		daoObj.addAirport(ap);		
	}

	@Override
	public void addFlightInformation(FlightInformation flightInfo)
	{
		daoObj.addFlightInformation(flightInfo);
	}

	@Override
	public int addBookingInformation(BookingInformation bookingEntry) 
	{
		return daoObj.addBookingInformation(bookingEntry);
	}

	@Override
	public ArrayList<FlightInformation> showOnDate(Date date) 
	{
		return daoObj.showOnDate(date);
	}

	@Override
	public ArrayList<FlightInformation> viewFlightBtw(String depArp, String arrArp) 
	{
		return daoObj.viewFlightBtw(depArp, arrArp);
	}

	@Override
	public ArrayList<BookingInformation> viewBookings(int flightNo) 
	{
		return daoObj.viewBookings(flightNo);
	}

	@Override
	public FlightInformation viewFlightDetail(int flightNo) 
	{
		return daoObj.viewFlightDetail(flightNo);
	}

	@Override
	public  HashMap<String, Airport> getAirportList() 
	{
		return daoObj.getAirportList();
	}

	@Override
	public ArrayList<FlightInformation> viewFlightOn(String depArp,
			String arrArp, Date date) 
	{
		return daoObj.viewFlightOn(depArp,arrArp,date) ;
	}

	@Override
	public ArrayList<FlightInformation> showAllFlights()
	{
		return daoObj.showAllFlights();
	}

	@Override
	public void updateFlightInformation(FlightInformation updateflight) {
		
		daoObj.updateFlightInformation(updateflight);
		
	}
}
