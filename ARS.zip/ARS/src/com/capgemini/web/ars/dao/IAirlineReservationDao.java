package com.capgemini.web.ars.dao;

import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;

import com.capgemini.web.ars.bean.Airport;
import com.capgemini.web.ars.bean.BookingInformation;
import com.capgemini.web.ars.bean.FlightInformation;

public interface IAirlineReservationDao 
{
	public void addAirport(Airport ap);
	public void addFlightInformation(FlightInformation flightInfo);
	public int addBookingInformation(BookingInformation bookingEntry);
	public ArrayList <FlightInformation> showOnDate(Date date);
	public ArrayList<FlightInformation> viewFlightBtw(String depArp , String arrArp);
	public ArrayList<BookingInformation> viewBookings(int flightNo);
	public FlightInformation viewFlightDetail(int flightNo);
	public  HashMap<String, Airport> getAirportList();
	public ArrayList<FlightInformation> viewFlightOn(String depArp,String arrArp, Date date);
	public ArrayList<FlightInformation> showAllFlights();
	
	//**************update flight information for admin

	public void updateFlightInformation(FlightInformation updateflight);
	
}
