package com.capgemini.springpractice.dao;

import java.util.List;

import com.capgemini.springpractice.dto.Trainee;

public interface ITraineeDao
{

	public int addTrainee(Trainee train);
	public List<Trainee> deleteTrainee(int traineeId);
	public List<Trainee> showAll();
	public List<Trainee> show(int traineeId);
	public void  update(Trainee trainee);
}
