package com.capgemini.springpractice.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.springpractice.dto.Trainee;

@Repository("traineedao")

public class TraineeDaoImpl implements ITraineeDao
{

	@PersistenceContext
	EntityManager entitymanager;
	
	@Override
	public int addTrainee(Trainee train) 
	{
		
		entitymanager.persist(train);			
		entitymanager.flush();					
		return train.getTraineeId();
		
	}

	@Override
	public List<Trainee> deleteTrainee(int traineeId) {
		Query queryTwo = entitymanager.createQuery("FROM Trainee WHERE traineeId=:TRAINEEID");
		queryTwo.setParameter("TRAINEEID", traineeId);
		List<Trainee> myList = queryTwo.getResultList();
		
		
		Query queryThree = entitymanager.createQuery("DELETE FROM Trainee where traineeId=:TRAINEEID");
		queryThree.setParameter("TRAINEEID", traineeId);
		queryThree.executeUpdate();
		
		return myList;
	}

	@Override
	public List<Trainee> showAll() {
		Query queryFour = entitymanager.createQuery("FROM Trainee");
		List<Trainee> myList = queryFour.getResultList();
		return myList;
	}

	@Override
	public List<Trainee> show(int traineeId) {
		Query queryFive = entitymanager.createQuery("FROM Trainee WHERE traineeId=:TRAINEEID");
		queryFive.setParameter("TRAINEEID", traineeId);
		List<Trainee> myList=queryFive.getResultList();
				return myList;
	}

	@Override
	public void update(Trainee trainee) {
		Query querySix = entitymanager.createQuery("UPDATE Trainee SET traineeId=:TRAINEEID, traineeName=:TRAINEENAME, traineeDomain=:TRAINEEDOMAIN,  traineeLocation=:TRAINEELOCATION WHERE traineeId=:TRAINEEID ");
		querySix.setParameter("TRAINEEID" ,trainee.getTraineeId() );
		querySix.setParameter("TRAINEENAME" ,trainee.getTraineeName() );
		querySix.setParameter("TRAINEEDOMAIN" ,trainee.getTraineeDomain());
		querySix.setParameter("TRAINEELOCATION" ,trainee.getTraineeLocation());
		querySix.executeUpdate();
	}

}
