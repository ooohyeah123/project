package com.capgemini.springpractice.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.enterprise.inject.Model;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingErrorProcessor;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.springpractice.dto.Trainee;
import com.capgemini.springpractice.service.ITraineeService;
import com.sun.org.apache.xpath.internal.operations.Mod;

@Controller
public class TraineeController
{

	@Autowired
	ITraineeService traineeservice;
	
	@RequestMapping(value="add", method=RequestMethod.GET)
	public String  insertTrainee(@ModelAttribute("my") Trainee trn,Map<String,Object> model)
	{
		List<String> myList = new ArrayList<String>();
		myList.add("Select");
		myList.add("Java");
		myList.add(".NET");
		myList.add("Testing");
		myList.add("SAP");
		myList.add("VNV");
		myList.add("BU");
		
		model.put("ptype", myList);
		
		
		return "addTrainee";
		
	}
	
	@RequestMapping(value="putdata",method=RequestMethod.POST)
	public ModelAndView add(@Valid@ModelAttribute("my") Trainee train,BindingResult error,Map<String,Object> model)
	{
		if(error.hasErrors())
		{
			List<String> myList = new ArrayList<String>();
			myList.add("Select");
			myList.add("Java");
			myList.add(".NET");
			myList.add("Testing");
			myList.add("SAP");
			myList.add("VNV");
			myList.add("BU");
			
			model.put("ptype", myList);
			
			
			
			return new ModelAndView("addTrainee");
		}
		else
		{
			int trainID = traineeservice.addTrainee(train);
			return new ModelAndView("success", "trainee", trainID);
		}
		
	}
	
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String remove(@ModelAttribute("my")Trainee train)
	
	{
		
			return "deletetrainee";
		
	}
	
	@RequestMapping(value="delTrainee", method=RequestMethod.POST)
	public ModelAndView removeTrainee(@ModelAttribute("my")Trainee train)
	{
		int trainId = train.getTraineeId();
		List<Trainee> myList = traineeservice.deleteTrainee(trainId);
		return new ModelAndView("deletedTrainee", "showTrainee", myList);
		
		
	}
	
	
	
	@RequestMapping(value="showall",method=RequestMethod.GET)
	public ModelAndView viewAll(@ModelAttribute("show")Trainee train)
	
	{
		
		List<Trainee> myList =  traineeservice.showAll();
		return new ModelAndView("show","showTrainee", myList);
		
	}
	
	@RequestMapping(value="search", method=RequestMethod.GET)
	public String search(@ModelAttribute("show") Trainee trn){
		
		
		return "searchId";
	
		
	}
	
	
	@RequestMapping(value="searchTrainee",method=RequestMethod.POST)
	public ModelAndView searchTrainee(@ModelAttribute("show")Trainee train)
	
	{
		int trainId = train.getTraineeId();
		List<Trainee> myList =  traineeservice.show(trainId);
		return new ModelAndView("retrieve","showTrainee", myList);
		
	}
	
	
	@RequestMapping(value="update",method=RequestMethod.GET)
	public String updatetrain(@ModelAttribute("my")Trainee train)
	{
		return "update";
		
	}
	
	@RequestMapping(value="fetchData",method=RequestMethod.POST)
	public ModelAndView searchData(@ModelAttribute("my")Trainee train,Map<String,Object> model)
	
	{

		List<String> myList = new ArrayList<String>();
		myList.add("Select");
		myList.add("Java");
		myList.add(".NET");
		myList.add("Testing");
		myList.add("SAP");
		myList.add("VNV");
		myList.add("BU");
		model.put("ptype", myList);
		
		
		int trainId = train.getTraineeId();
		
		List<Trainee> traineeId = traineeservice.show(trainId);
		
		return new ModelAndView("updateTrainee", "data", traineeId);
	}	
	
	@RequestMapping(value="savedata",method=RequestMethod.POST)
	public String up(@ModelAttribute("my")Trainee train)
	{
		
		 traineeservice.update(train);
		 
		return "updateStatus";
		
	}
}




